package com.fundsbank.app;

import javax.el.MethodNotFoundException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.fundsbank.app.model.Customer;
import com.fundsbank.app.service.ICustomerComplaintService;
import com.fundsbank.exception.CustomException;

@Controller
public class AppController {

	@Autowired
	private ICustomerComplaintService customerComplaintService;
	
	public AppController() {
		//customerComplaintService = new CustomerComplaintService();
	}
	
	
	@RequestMapping("/")
	public ModelAndView getRootPage(Model model) {
		
		return new ModelAndView("index");
	}
	
	@RequestMapping("/index")
	public ModelAndView getIndexPage(Model model) {
		
		return new ModelAndView("index");
	}
	
	
	@RequestMapping("/complaint_raise")
	public ModelAndView raiseComplaint(Model model) {
		
		//Customer customer = new Customer(1,6878945,"FCFC12","akhilesh@cdac.in","Internet Banking","Net Banking disabled","High","Closed");
		//this.customerComplaintService.addCustomerComplaint(customer);
		
		Customer customer = new Customer();
		model.addAttribute("customer", customer);
		
		return new ModelAndView("complaint_raise");
	}
	
	@RequestMapping(value = "/add_complaint", method = RequestMethod.POST)
	@ExceptionHandler({ CustomException.class ,NoSuchMethodException.class})
	public String addComplaint(@ModelAttribute("customer") @Valid Customer p, BindingResult result, Model model) {
		
		System.out.println(result.hasErrors());
		
		if (result.hasErrors()) {
			return "complaint_raise";
		}else {
			
			if(p.getCategory().equals("Internet Banking")) {
				p.setPriority("High");
			}
			
			if(p.getCategory().equals("General Banking")) {
				p.setPriority("Medium");
			}
			
			if(p.getCategory().equals("Others")) {
				p.setPriority("Low");
			}
			
			p.setStatus("open");
			
			
			this.customerComplaintService.addCustomerComplaint(p);  // new student, add it
			int cid = p.getComplaintId();
			model.addAttribute("complaintID", cid);
			return "redirect:/complaint_success";
		}
		
	}
	
	
	
	@RequestMapping("/complaint_status")
	public ModelAndView getComplaintStatus(Model model) {
		
		Customer customer = new Customer();
		model.addAttribute("customer", customer);
		
		return new ModelAndView("complaint_status");
	}
	
	
	

	@RequestMapping(value = "/get_complaint_details", method = RequestMethod.POST)
	public String getComplaintDetails(@ModelAttribute("customer") @Valid Customer p, BindingResult result, Model model) {
		
		Customer customer = this.customerComplaintService.getCustomerComplaintDetailsByID(p.getComplaintId());
		model.addAttribute("customerdata", customer);
		
		System.out.println(customer);
		
		return "complaint_status";
	}
	
	
	
	@RequestMapping("/complaint_success")
	public ModelAndView complaintConfirmPage(Model model) {
		
		return new ModelAndView("complaint_success");
	}
	
	@RequestMapping("/showErrorPage/error")
	public ModelAndView exception(Exception e) {

		ModelAndView mav = new ModelAndView("error");// view name
		mav.addObject("exName", e.getClass().getSimpleName());// model for ex name
		mav.addObject("exMessage", e.getMessage());// model for ex msg
		return mav;
	}
	
	
	

}
