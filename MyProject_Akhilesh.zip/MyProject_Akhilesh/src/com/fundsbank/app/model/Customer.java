package com.fundsbank.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "complaintid")
	private Integer complaintId;
	
	@Min(10)
	//@Max(11)
	@Column(name = "accountid")
	private Integer accountId;
	
	
	@Size(min = 4, max = 10)
	@NotEmpty(message = "Branch Code is Mandatory!!")
	@Column(name = "branchcode")
	private String branchCode;
	
	
	@NotEmpty
	@Email(message = "Please Enter valid Email Id")
	@Column(name = "emailid")
	private String emailId;
	
	@Column(name = "category")
	private String category;
	
	@Size(min = 2, max = 25)
	@NotEmpty(message = "Name is Mandatory!!")
	@Column(name = "description")
	private String description;
	
	@Column(name = "priority")
	private String priority;
	
	@Column(name = "status")
	private String status;
	
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Customer(Integer complaintId, Integer accountId, String branchCode, String emailId, String category, String description,
			String priority, String status) {
		super();
		this.complaintId = complaintId;
		this.accountId = accountId;
		this.branchCode = branchCode;
		this.emailId = emailId;
		this.category = category;
		this.description = description;
		this.priority = priority;
		this.status = status;
	}



	public Integer getComplaintId() {
		return complaintId;
	}




	public void setComplaintId(Integer complaintId) {
		this.complaintId = complaintId;
	}




	public Integer getAccountId() {
		return accountId;
	}




	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}




	public String getBranchCode() {
		return branchCode;
	}




	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}




	public String getEmailId() {
		return emailId;
	}




	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}




	public String getCategory() {
		return category;
	}




	public void setCategory(String category) {
		this.category = category;
	}




	public String getDescription() {
		return description;
	}




	public void setDescription(String description) {
		this.description = description;
	}




	public String getPriority() {
		return priority;
	}




	public void setPriority(String priority) {
		this.priority = priority;
	}




	public String getStatus() {
		return status;
	}




	public void setStatus(String status) {
		this.status = status;
	}



	@Override
	public String toString() {
		return "Customer [complaintId=" + complaintId + ", accountId=" + accountId + ", branchCode=" + branchCode
				+ ", emailId=" + emailId + ", category=" + category + ", description=" + description + ", priority="
				+ priority + ", status=" + status + "]";
	}

	

	

}
