package com.fundsbank.app.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fundsbank.app.model.Customer;

@Repository
public class CustomerComplaintDao implements ICustomerComplaintDao {


	private SessionFactory sessionFactory;

	public CustomerComplaintDao() {
		// TODO Auto-generated constructor stub
	}
	
	
	public SessionFactory getSessionFactory() {
		return this.sessionFactory;
	}

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		System.out.println("Session Factory : "+sessionFactory);
		this.sessionFactory = sessionFactory;
	}
	
	
	@Override
	@Transactional
	public Customer addCustomerComplaint(Customer customer) {
		
		System.out.println("Dao "+customer);
		
		Session session = this.sessionFactory.getCurrentSession();
		
		session.save(customer);
		
		return customer;
	}

	@Override
	@Transactional
	public Customer getCustomerComplaintDetailsByID(Integer complaintId) {
		Session session = this.sessionFactory.getCurrentSession();
		
		System.out.println(complaintId);
		
		Customer cst = (Customer) session.load(Customer.class, new Integer(complaintId));
		
		System.out.println(cst);
		
		return cst;
	}

}
