package com.fundsbank.app.dao;

import com.fundsbank.app.model.Customer;

public interface ICustomerComplaintDao {

	
	public Customer addCustomerComplaint(Customer customer);
	
	public Customer getCustomerComplaintDetailsByID(Integer complaintId);


}
