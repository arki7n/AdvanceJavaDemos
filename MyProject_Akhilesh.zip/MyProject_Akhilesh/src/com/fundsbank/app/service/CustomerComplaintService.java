package com.fundsbank.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.fundsbank.app.dao.ICustomerComplaintDao;
import com.fundsbank.app.model.Customer;

@Service
public class CustomerComplaintService implements ICustomerComplaintService {

	@Autowired
	private ICustomerComplaintDao customerComplaintDao;
	
	public CustomerComplaintService() {
		//this.customerComplaintDao = new CustomerComplaintDao();
	}

	@Override
	public Customer addCustomerComplaint(Customer customer) {
		System.out.println("Inside Service" + customer);
		return this.customerComplaintDao.addCustomerComplaint(customer);
	}

	@Override
	public Customer getCustomerComplaintDetailsByID(Integer complaintId) {
		return this.customerComplaintDao.getCustomerComplaintDetailsByID(complaintId);
	}

}
