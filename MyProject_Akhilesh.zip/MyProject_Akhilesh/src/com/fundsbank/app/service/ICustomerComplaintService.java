package com.fundsbank.app.service;

import com.fundsbank.app.model.Customer;

public interface ICustomerComplaintService {

	public Customer addCustomerComplaint(Customer customer);
	
	public Customer getCustomerComplaintDetailsByID(Integer complaintId);

}
